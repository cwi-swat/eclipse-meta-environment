#ifndef __Location_dict_H
#define __Location_dict_H

#include <aterm2.h>

extern AFun LOC_afun4;
extern AFun LOC_afun0;
extern AFun LOC_afun2;
extern AFun LOC_afun3;
extern AFun LOC_afun1;


extern void init_Location_dict();

#endif /* __Location_dict_H */
