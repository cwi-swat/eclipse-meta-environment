#ifndef PT2SDF_H
#define PT2SDF_H
 
#include <MEPT.h>
#include <SDFME.h>
 
SDF_Production PTProductionToSDFProduction(PT_Production pt);
SDF_Symbol PTSymbolToSDFSymbol(PT_Symbol pt);
 
#endif
