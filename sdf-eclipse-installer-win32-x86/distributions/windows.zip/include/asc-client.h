
ATerm asf_toolbus_handler(int cid, ATerm trm);
