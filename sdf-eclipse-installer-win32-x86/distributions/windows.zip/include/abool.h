#ifndef ABOOL_H
#define ABOOL_H

#ifdef __cplusplus
extern "C"
{
#endif/* __cplusplus */

typedef enum { ATfalse=0, ATtrue } ATbool;

#ifdef __cplusplus
}
#endif/* __cplusplus */ 

#endif
