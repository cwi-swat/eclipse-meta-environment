/*$Id: inputString-data.h 17661 2006-02-03 12:14:14Z economop $*/

#ifndef __INPUT_STRING_DATA__
#define  __INPUT_STRING_DATA__

typedef struct _InputString *InputString;

#endif /* __INPUT_STRING_DATA__ */


