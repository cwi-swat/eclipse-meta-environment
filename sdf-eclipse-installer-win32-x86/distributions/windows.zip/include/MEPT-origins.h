#ifndef MEPT_ORIGINS
#define MEPT_ORIGINS
#include <MEPT.h>
#include <Location.h>

PT_Tree PT_promotePosInfoToOrigin(PT_Tree tree);
LOC_Location PT_getTreeOrigin(PT_Tree tree);
#endif
