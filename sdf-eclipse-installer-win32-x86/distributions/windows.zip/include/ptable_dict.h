#ifndef __ptable_dict_H
#define __ptable_dict_H

#include <aterm2.h>

extern AFun PTBL_afun8;
extern AFun PTBL_afun0;
extern AFun PTBL_afun11;
extern AFun PTBL_afun5;
extern AFun PTBL_afun3;
extern AFun PTBL_afun9;
extern AFun PTBL_afun10;
extern AFun PTBL_afun4;
extern AFun PTBL_afun13;
extern AFun PTBL_afun2;
extern AFun PTBL_afun7;
extern AFun PTBL_afun12;
extern AFun PTBL_afun6;
extern AFun PTBL_afun1;


extern void init_ptable_dict();

#endif /* __ptable_dict_H */
