#ifndef __RStore_dict_H
#define __RStore_dict_H

#include <aterm2.h>

extern AFun RS_afun17;
extern AFun RS_afun22;
extern AFun RS_afun3;
extern AFun RS_afun9;
extern AFun RS_afun19;
extern AFun RS_afun2;
extern AFun RS_afun12;
extern AFun RS_afun15;
extern AFun RS_afun18;
extern AFun RS_afun20;
extern AFun RS_afun8;
extern AFun RS_afun21;
extern AFun RS_afun0;
extern AFun RS_afun11;
extern AFun RS_afun5;
extern AFun RS_afun16;
extern AFun RS_afun10;
extern AFun RS_afun13;
extern AFun RS_afun4;
extern AFun RS_afun14;
extern AFun RS_afun23;
extern AFun RS_afun7;
extern AFun RS_afun24;
extern AFun RS_afun1;
extern AFun RS_afun6;


extern void init_RStore_dict();

#endif /* __RStore_dict_H */
