#ifndef __Error_dict_H
#define __Error_dict_H

#include <aterm2.h>

extern AFun ERR_afun8;
extern AFun ERR_afun4;
extern AFun ERR_afun0;
extern AFun ERR_afun2;
extern AFun ERR_afun11;
extern AFun ERR_afun7;
extern AFun ERR_afun5;
extern AFun ERR_afun3;
extern AFun ERR_afun9;
extern AFun ERR_afun10;
extern AFun ERR_afun1;
extern AFun ERR_afun6;


extern void init_Error_dict();

#endif /* __Error_dict_H */
