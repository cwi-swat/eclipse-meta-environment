#ifndef __IO_dict_H
#define __IO_dict_H

#include <aterm2.h>

extern AFun IO_afun0;
extern AFun IO_afun2;
extern AFun IO_afun3;
extern AFun IO_afun1;


extern void init_IO_dict();

#endif /* __IO_dict_H */
