#ifndef DEPRECATED_H
#define DEPRECATED_H

/* Use of this file is deprecated ;-) */

#endif
