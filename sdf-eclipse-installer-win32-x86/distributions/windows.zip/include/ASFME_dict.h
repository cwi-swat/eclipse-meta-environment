#ifndef __ASFME_dict_H
#define __ASFME_dict_H

#include <aterm2.h>

extern AFun ASF_afun17;
extern AFun ASF_afun3;
extern AFun ASF_afun78;
extern AFun ASF_afun48;
extern AFun ASF_afun34;
extern AFun ASF_afun59;
extern AFun ASF_afun37;
extern AFun ASF_afun26;
extern AFun ASF_afun19;
extern AFun ASF_afun63;
extern AFun ASF_afun2;
extern AFun ASF_afun47;
extern AFun ASF_afun80;
extern AFun ASF_afun42;
extern AFun ASF_afun25;
extern AFun ASF_afun15;
extern AFun ASF_afun75;
extern AFun ASF_afun18;
extern AFun ASF_afun31;
extern AFun ASF_afun69;
extern AFun ASF_afun43;
extern AFun ASF_afun54;
extern AFun ASF_afun0;
extern AFun ASF_afun38;
extern AFun ASF_afun33;
extern AFun ASF_afun16;
extern AFun ASF_afun77;
extern AFun ASF_afun10;
extern AFun ASF_afun13;
extern AFun ASF_afun52;
extern AFun ASF_afun40;
extern AFun ASF_afun14;
extern AFun ASF_afun74;
extern AFun ASF_afun30;
extern AFun ASF_afun60;
extern AFun ASF_afun7;
extern AFun ASF_afun58;
extern AFun ASF_afun79;
extern AFun ASF_afun57;
extern AFun ASF_afun35;
extern AFun ASF_afun81;
extern AFun ASF_afun29;
extern AFun ASF_afun6;
extern AFun ASF_afun1;
extern AFun ASF_afun39;
extern AFun ASF_afun61;
extern AFun ASF_afun72;
extern AFun ASF_afun50;
extern AFun ASF_afun22;
extern AFun ASF_afun44;
extern AFun ASF_afun66;
extern AFun ASF_afun73;
extern AFun ASF_afun9;
extern AFun ASF_afun51;
extern AFun ASF_afun56;
extern AFun ASF_afun41;
extern AFun ASF_afun12;
extern AFun ASF_afun53;
extern AFun ASF_afun64;
extern AFun ASF_afun70;
extern AFun ASF_afun20;
extern AFun ASF_afun28;
extern AFun ASF_afun8;
extern AFun ASF_afun21;
extern AFun ASF_afun32;
extern AFun ASF_afun65;
extern AFun ASF_afun76;
extern AFun ASF_afun11;
extern AFun ASF_afun62;
extern AFun ASF_afun27;
extern AFun ASF_afun5;
extern AFun ASF_afun55;
extern AFun ASF_afun4;
extern AFun ASF_afun67;
extern AFun ASF_afun23;
extern AFun ASF_afun49;
extern AFun ASF_afun45;
extern AFun ASF_afun71;
extern AFun ASF_afun68;
extern AFun ASF_afun36;
extern AFun ASF_afun24;
extern AFun ASF_afun46;


extern void init_ASFME_dict();

#endif /* __ASFME_dict_H */
