/* $Id: asc-muasf2pt.h 18086 2006-03-08 13:04:28Z jurgenv $ */

#ifndef _MUASF2PT_H
#define _MUASF2PT_H

#include <MEPT.h>

PT_Tree muASFToTree(ATerm tree);
PT_Tree muASFToTreeWithLayout(ATerm tree, PT_Tree layout);

#endif
