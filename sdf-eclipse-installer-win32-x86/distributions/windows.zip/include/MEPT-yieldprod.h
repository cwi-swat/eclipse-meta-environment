#ifndef MEPT_YIELDPROD
#define MEPT_YIELDPROD
#include <MEPT.h>

char *PT_yieldSymbolVisualVariables(PT_Symbol symbol);
char *PT_yieldSymbol(PT_Symbol symbol);
char *PT_yieldProduction(PT_Production prod);

#endif
