#ifndef __MEPT_dict_H
#define __MEPT_dict_H

#include <aterm2.h>

extern AFun PT_afun39;
extern AFun PT_afun17;
extern AFun PT_afun22;
extern AFun PT_afun3;
extern AFun PT_afun9;
extern AFun PT_afun34;
extern AFun PT_afun19;
extern AFun PT_afun26;
extern AFun PT_afun37;
extern AFun PT_afun2;
extern AFun PT_afun41;
extern AFun PT_afun12;
extern AFun PT_afun15;
extern AFun PT_afun25;
extern AFun PT_afun18;
extern AFun PT_afun20;
extern AFun PT_afun31;
extern AFun PT_afun8;
extern AFun PT_afun28;
extern AFun PT_afun21;
extern AFun PT_afun32;
extern AFun PT_afun0;
extern AFun PT_afun11;
extern AFun PT_afun5;
extern AFun PT_afun27;
extern AFun PT_afun33;
extern AFun PT_afun38;
extern AFun PT_afun16;
extern AFun PT_afun10;
extern AFun PT_afun13;
extern AFun PT_afun4;
extern AFun PT_afun14;
extern AFun PT_afun40;
extern AFun PT_afun23;
extern AFun PT_afun30;
extern AFun PT_afun7;
extern AFun PT_afun36;
extern AFun PT_afun24;
extern AFun PT_afun35;
extern AFun PT_afun29;
extern AFun PT_afun1;
extern AFun PT_afun6;


extern void init_MEPT_dict();

#endif /* __MEPT_dict_H */
