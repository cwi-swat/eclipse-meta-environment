#ifndef __ParsedRStore_dict_H
#define __ParsedRStore_dict_H

#include <aterm2.h>

extern AFun PRS_afun17;
extern AFun PRS_afun3;
extern AFun PRS_afun78;
extern AFun PRS_afun48;
extern AFun PRS_afun34;
extern AFun PRS_afun59;
extern AFun PRS_afun37;
extern AFun PRS_afun26;
extern AFun PRS_afun19;
extern AFun PRS_afun63;
extern AFun PRS_afun2;
extern AFun PRS_afun47;
extern AFun PRS_afun80;
extern AFun PRS_afun42;
extern AFun PRS_afun25;
extern AFun PRS_afun15;
extern AFun PRS_afun75;
extern AFun PRS_afun18;
extern AFun PRS_afun31;
extern AFun PRS_afun69;
extern AFun PRS_afun43;
extern AFun PRS_afun54;
extern AFun PRS_afun0;
extern AFun PRS_afun38;
extern AFun PRS_afun33;
extern AFun PRS_afun16;
extern AFun PRS_afun77;
extern AFun PRS_afun10;
extern AFun PRS_afun13;
extern AFun PRS_afun52;
extern AFun PRS_afun40;
extern AFun PRS_afun14;
extern AFun PRS_afun74;
extern AFun PRS_afun82;
extern AFun PRS_afun30;
extern AFun PRS_afun60;
extern AFun PRS_afun7;
extern AFun PRS_afun58;
extern AFun PRS_afun79;
extern AFun PRS_afun57;
extern AFun PRS_afun35;
extern AFun PRS_afun81;
extern AFun PRS_afun29;
extern AFun PRS_afun6;
extern AFun PRS_afun1;
extern AFun PRS_afun39;
extern AFun PRS_afun83;
extern AFun PRS_afun61;
extern AFun PRS_afun72;
extern AFun PRS_afun50;
extern AFun PRS_afun22;
extern AFun PRS_afun44;
extern AFun PRS_afun66;
extern AFun PRS_afun73;
extern AFun PRS_afun9;
extern AFun PRS_afun51;
extern AFun PRS_afun56;
extern AFun PRS_afun41;
extern AFun PRS_afun12;
extern AFun PRS_afun53;
extern AFun PRS_afun64;
extern AFun PRS_afun70;
extern AFun PRS_afun20;
extern AFun PRS_afun28;
extern AFun PRS_afun8;
extern AFun PRS_afun21;
extern AFun PRS_afun32;
extern AFun PRS_afun65;
extern AFun PRS_afun76;
extern AFun PRS_afun11;
extern AFun PRS_afun62;
extern AFun PRS_afun27;
extern AFun PRS_afun5;
extern AFun PRS_afun55;
extern AFun PRS_afun4;
extern AFun PRS_afun67;
extern AFun PRS_afun23;
extern AFun PRS_afun49;
extern AFun PRS_afun45;
extern AFun PRS_afun71;
extern AFun PRS_afun68;
extern AFun PRS_afun36;
extern AFun PRS_afun24;
extern AFun PRS_afun46;


extern void init_ParsedRStore_dict();

#endif /* __ParsedRStore_dict_H */
