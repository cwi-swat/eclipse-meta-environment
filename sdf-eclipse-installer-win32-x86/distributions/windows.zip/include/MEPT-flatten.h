#ifndef MEPT_FLATTEN
#define MEPT_FLATTEN
#include <MEPT.h>

void PT_initAsFix2Api();
PT_ParseTree flattenPT(PT_ParseTree tree);
PT_Tree flattenTree(PT_Tree tree);
#endif
